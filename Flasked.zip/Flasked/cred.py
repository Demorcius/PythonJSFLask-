# Credential File link
CREDENTIALS_FILE = "data/credentials.json"

# Folder Paths
Gallery_Folder = "static/photos/"